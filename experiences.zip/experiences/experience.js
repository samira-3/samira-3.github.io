const jobs = document.querySelectorAll(".job");

jobs.forEach((job) => {
    job.addEventListener("click", () => {
        job.classList.toggle("flipped");
    });
});

window.addEventListener("scroll", () => {
    const timeline = document.querySelector(".timeline");
    const timelineTop = timeline.getBoundingClientRect().top;
    if (timelineTop < window.innerHeight) {
        jobs.forEach((job) => {
            job.style.opacity = 1;
        });
    } else {
        jobs.forEach((job) => {
            job.style.opacity = 0;
        });
    }
});
